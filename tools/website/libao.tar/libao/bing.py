# -*- coding: utf-8 -*-
import requests
from pyquery import PyQuery as Pq
import time


def get_urls(key):
    time.sleep(10)
    url = 'http://www.bing.com/search?q=site%3a115.com%2flb+{}&count=50'.format(key)
    d = requests.get(url)
    p = Pq(d.text, parser='html')
    a_s = p('a').filter(lambda i, this: Pq(this).attr('href')).filter(lambda i, this: Pq(this).attr('href').startswith('http://115.com/lb'))
    return [i.attr('href') for i in a_s.items()]
