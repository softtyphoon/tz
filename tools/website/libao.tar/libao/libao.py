# -*- coding: utf-8 -*-

from app import app
from views import lb
app.register_blueprint(lb)