# -*- cofing: utf-8 -*-
from pyquery import PyQuery as Pq
from models import Libao
from size import to_b
from spider import headers
from string_plus import StringPlus
import asyncio
import aiohttp


@asyncio.coroutine
def scrap(lb_code):
    d = yield from get('http://115.com/lb/%s' % lb_code)
    p = Pq(d)
#    print(lb_code)
    title = p('.spree-info span').attr('title')
    if not title:
        return None
    size = p('.spree-info em').text().split('大小：')[-1]
    code = p('#js_gift_code').attr('value')
    libao, created = Libao.objects.get_or_create(title=title, code=code, size=to_b(size))
    if created:
        print(libao.code)


@asyncio.coroutine
def get(url):
    response = yield from aiohttp.request('GET', url=url, headers=headers())
    return (yield from response.read())


def task_generator(start='0000'):
    a = StringPlus(start)
    while True:
        yield [scrap('5lb%s' % a.next()) for _i in range(0, 100)]

if __name__ == '__main__':
    loop = asyncio.get_event_loop()
    tt = task_generator()
    for i in tt:
        f = asyncio.wait(i, timeout=3)
        loop.run_until_complete(f)
