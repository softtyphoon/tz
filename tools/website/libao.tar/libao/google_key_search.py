#!/usr/bin/env python
# -*- coding: utf-8 -*-

from pyquery import PyQuery as Pq
from models import Libao
from size import to_b
from spider import headers
from string_plus import StringPlus
from utils import get_from_115
import asyncio
import aiohttp
import google
import sys
import time
import bing


def all_code(key):
    return bing.get_urls(key)


@asyncio.coroutine
def scrap(url):
    d = yield from get(url)
    p = Pq(d)
    title = p('.spree-info span').attr('title')
    if not title:
        return None
    size = p('.spree-info em').text().split('大小：')[-1]
    code = p('#js_gift_code').attr('value')
    libao, created = Libao.objects.get_or_create(title=title, code=code, size=to_b(size))
    if created:
        print(libao.code)


@asyncio.coroutine
def get(url):
    response = yield from aiohttp.request('GET', url=url, headers=headers())
    return (yield from response.read())


def task_generator(key):
    yield [scrap(lb_code) for lb_code in all_code(key)]

def __scrap_key(key):
    loop = asyncio.get_event_loop()
    tt = task_generator(key)
    for i in tt:
        f = asyncio.wait(i, timeout=10)
        loop.run_until_complete(f)


def scrap_key(key):
    for i in all_code(key):
        get_from_115(i)


if __name__ == '__main__':
    key = sys.argv[1]
    __scrap_key(key)
