# -*- coding: utf-8 -*-
from pyquery import PyQuery as Pq
from models import Libao
from size import to_b
import asyncio
import aiohttp
import datetime
import random


def ip():
    return '.'.join([str(x) for x in [random.randint(1, 254),
                                      random.randint(1, 254),
                                      random.randint(1, 254),
                                      random.randint(1, 254)]])


def headers():
    return {
        'User-agent':
        """Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.120 Safari/537.36"""
        ,
        'X-Forwarded-For': ip()
    }


class LibaoSpider(object):

    def __init__(self, d):
        self.tree = Pq(d)

    @property
    def title(self):
        return self.tree('div.name').text().split('：')[-1]

    @property
    def size(self):
        return self.tree('div.size').text().split('：')[1].split()[0]

    @property
    def code(self):
        return self.tree('div.size').text().split('：')[-1]

    @property
    def update_time(self):
        return datetime.datetime.strptime(self.tree('div.date').text().split('：')[-1], '%Y-%m-%d %H:%M:%S')

    @property
    def info(self):
        return dict(title=self.title, size=self.size, code=self.code, update_time=self.update_time, lid=self.lid)

    @property
    def lid(self):
        return self.tree('div.link > a').attr('href').split('/')[-1].split('.html')[0]

@asyncio.coroutine
def get(url):
    response = yield from aiohttp.request('GET', url=url, headers=headers())
    return (yield from response.read())


@asyncio.coroutine
def get_info(url):
    d = yield from get(url)
    s = LibaoSpider(d)
    print(s.info)


@asyncio.coroutine
def scrap(lid):
    url = 'http://www.libao.so/{}.html'
    d = yield from get(url.format(lid))
    s = LibaoSpider(d)
    try:
        info = s.info
    except:
        # print(s.tree)
        pass
    else:
        l, created = Libao.objects.get_or_create(code=info['code'],
                                                 title=info['title'],
                                                 size=to_b(info['size']),
                                                 update_time=info['update_time'],
                                                 )
        if created:
            print(info['lid'])


def tasks(a, b):
    return [scrap(i) for i in range(a, b+1)]