# -*- coding: utf-8 -*-

from app import app
from views import lb
from flask_debugtoolbar import DebugToolbarExtension

app.register_blueprint(lb)

app.config['SECRET_KEY'] = 'libao'

toolbar = DebugToolbarExtension(app)

app.run(debug=True, host="0.0.0.0")