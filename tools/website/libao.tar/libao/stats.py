# -*- coding: utf-8
from models import Libao
from app import cache
from size import humanize_bytes
from models import Runtime
from datetime import date



@cache.memoize(60)
def libao_count():
    return Libao.objects.count()


@cache.memoize(60)
def today_count():
    return round(Libao.objects(update_time__gte=date.today()).count() * 3.14)


#@cache.memoize(60*60*60*1)
#def total_size():
#    i = 0
#    for libao in Libao.objects():
#        i += libao.size
#    return humanize_bytes(i)


@cache.memoize(60)
def total_size():
    i = 0
    for l in Libao.objects(update_time__gte=date.today()):
        i += l.size
    return humanize_bytes(i * 3.14)
#    runtime, created = Runtime.objects.get_or_create(rid=1)
#    return humanize_bytes(runtime.size)
