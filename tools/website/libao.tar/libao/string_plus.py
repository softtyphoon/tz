# -*- coding: utf-8 -*-
import string

chars = string.digits + string.ascii_lowercase


class StringPlus(object):

    def __init__(self, s):
        self.s = s

    def __str__(self):
        return self.s

    def __repr__(self):
        return self.__str__()

    def next(self):
        if set(list(self.s)) == {'z'}:
            self.s = '1' + '0' * len(self.s)
            return self.s
        for i in list(range(0, len(self.s)))[::-1]:
            ind = chars.index(self.s[i])
            if ind == 35:
                l = list(self.s)
                l[i] = '0'
                self.s = ''.join(l)
                continue
            else:
                l = list(self.s)
                l[i] = chars[ind+1]
                self.s = ''.join(l)
                return self.s
