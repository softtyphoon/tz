# -*- coding: utf-8 -*-

UNITS = ['B', 'KB', 'MB', 'GB', 'TB', 'PB']


def to_b(s):
    digits = ''
    unit = ''
    for i in s:
        if i.isdigit() or i == '.':
            digits += i
        else:
            unit += i
    real_size = float(digits) * 1024 ** UNITS.index(unit)
    return real_size


def humanize_bytes(bytesize, precision=2):
    """
    Humanize byte size figures
    """
    abbrevs = (
        # (1 << 50, 'PB'),
        (1 << 40, 'TB'),
        (1 << 30, 'GB'),
        (1 << 20, 'MB'),
        (1 << 10, 'kB'),
        (1, 'B')
    )
    if bytesize == 1:
        return '1 byte'
    for factor, suffix in abbrevs:
        if bytesize >= factor:
            break
    if factor == 1:
        precision = 0
    return '%.*f %s' % (precision, bytesize / float(factor), suffix)